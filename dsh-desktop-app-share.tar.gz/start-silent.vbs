Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "D:\ds\dsh-desktop-app"
WshShell.Run """D:\ds\dsh-desktop-app\node_modules\electron\dist\electron.exe"" .", 1, False
Set WshShell = Nothing
